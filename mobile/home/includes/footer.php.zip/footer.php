<div id="footer-bar" class="footer-bar-6" >
        
        <a href="homepage" class="text-" ><i class="fa fa-home" style ="color:<?php echo $sitecolor; ?>; opacity: 1;"></i><span style="opacity: 1;"><b>Home</b></span></a>
        <a href="profile" class="text-" ><i class="fa fa-user" style ="color:<?php echo $sitecolor; ?>; opacity: 1;"></i><span style="opacity: 1;"><b>Profile</b></span></a>
        <a href="transactions" class="text-" ><i class="fa fa-receipt" style ="color:<?php echo $sitecolor; ?>; opacity: 1;"></i><span style="opacity: 1;"><b>History</b></span></a>
        <a href="more-services" class="text-" ><i class="fa fa-list-alt" style ="color:<?php echo $sitecolor; ?>; opacity: 1;"></i><span style="opacity: 1;"><b>More</b></span></a>
        
</div>